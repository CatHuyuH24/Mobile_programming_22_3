package com.example.hw06_n02_22120144_22120149_22120158_22120159;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Objects;

public class MainActivity extends Activity {
    ProgressBar progressBar;
    EditText edtInputNumber;
    Button btnDoItAgain;
    TextView tvProgressInfo;

    int progress = 0;
    int absValInputNumber = 0;
    final int MAX_PROGRESS = 100;
    final int PROGRESS_STEP = 1;

    Handler myHandler = new Handler();

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        btnDoItAgain = findViewById(R.id.btnDoItAgain);
        edtInputNumber = findViewById(R.id.inputNumber);
        tvProgressInfo = findViewById(R.id.progressInfo);

        btnDoItAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startProgress();
            }
        });
    }

    private void startProgress(){

        try{
            String input = edtInputNumber.getText().toString();
            if(!input.isEmpty())
                absValInputNumber = Math.abs(Integer.parseInt(input));
            else
                return; //do nothing
        }catch (Exception e){
            Log.e("<<Error extracting the number from the editText>>",Objects.requireNonNull(e.getMessage()));
            absValInputNumber = 1000;// default value to fall back on
        }

        //reset and show progress bars
        progress = 0;
        progressBar.setMax(MAX_PROGRESS);
        progressBar.setProgress(0);
        tvProgressInfo.setText("0%");

        btnDoItAgain.setEnabled(false);
        edtInputNumber.setEnabled(false);

        Thread myBackgroundThread = new Thread(backgroundTask, "background_task");
        myBackgroundThread.start();
    }
    @Override
    protected void onStart() {
        super.onStart();

        //reset and show progress bars
        progress = 0;
        progressBar.setMax(MAX_PROGRESS);
        progressBar.setProgress(0);
        tvProgressInfo.setText("0%");
        edtInputNumber.setText("");
    }

    private final Runnable foregroundRunnable = new Runnable() {
        @Override
        public void run() {
            try{
                progressBar.incrementProgressBy(PROGRESS_STEP);
                progress += PROGRESS_STEP;
                String num = progress + "%";
                tvProgressInfo.setText(num);

                if(progress >= progressBar.getMax()){
                    btnDoItAgain.setEnabled(true);
                    edtInputNumber.setEnabled(true);
                }
            }catch(Exception e) {
                Log.e("<<Error executing foreground task>>", Objects.requireNonNull(e.getMessage()));
            }

        }
    };

    private final Runnable backgroundTask = new Runnable() {
        @Override
        public void run() {
            try{
                int n = (int) Math.ceil((double)(MAX_PROGRESS) / (double)(PROGRESS_STEP));
                for(int times = 0; times < n; times++)
                {
                    Thread.sleep((long)(100000/absValInputNumber));
                    myHandler.post(foregroundRunnable);
                }
            } catch (InterruptedException e) {
                Log.e("<<Error executing background task>>", Objects.requireNonNull(e.getMessage()));
                throw new RuntimeException(e);
            }
        }
    };
}


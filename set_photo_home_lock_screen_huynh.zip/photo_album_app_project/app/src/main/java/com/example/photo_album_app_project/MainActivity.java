package com.example.photo_album_app_project;

import android.app.WallpaperManager;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnChangeAppBg;
    private Button btnChangePhoneBg;
    private LinearLayout mainLinearLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnChangeAppBg = findViewById(R.id.btn_change_bg_app);
        mainLinearLayout = findViewById(R.id.main_linear_layout);
        btnChangePhoneBg = findViewById(R.id.btn_change_bg_phone);

        btnChangeAppBg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainLinearLayout.setBackgroundResource(R.drawable.bg_image);
                Toast.makeText(MainActivity.this,"Pressed changed-background button",Toast.LENGTH_LONG).show();
            }
        });

        btnChangePhoneBg.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                WallpaperManager wallpaperManger = WallpaperManager.getInstance(getApplicationContext());

                try {
                    //set home screen
                    wallpaperManger.setBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.eyes_bg_phone),null,true,WallpaperManager.FLAG_SYSTEM);
                    //set lock screen:
                    wallpaperManger.setBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.teddy_bg_lock),null,true,WallpaperManager.FLAG_LOCK);

                    Toast.makeText(MainActivity.this, "Wallpaper set successfully for home screen and lock screen", Toast.LENGTH_LONG).show();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Failed to set wallpaper", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
package live.enkay.horizontalscrollview;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.graphics.Color;
import android.graphics.drawable.Drawable;

public class MainActivity extends Activity {

    TextView txtMsg;
    ViewGroup scrollViewgroup;

    ImageView icon;
    TextView caption;

    ImageView imageSelected;

    String[] items = {"photo_1","photo_2","photo_3","photo_4", "photo_5", "photo_6", "photo_7", "photo_8"};

    Integer[] thumbnails = {R.drawable.photo_1, R.drawable.photo_2, R.drawable.photo_3, R.drawable.photo_4, R.drawable.photo_5, R.drawable.photo_6, R.drawable.photo_7, R.drawable.photo_8};

    Integer[] largeImages = {R.drawable.large_photo_1, R.drawable.large_photo_2, R.drawable.large_photo_3, R.drawable.large_photo_4, R.drawable.large_photo_5, R.drawable.large_photo_6, R.drawable.large_photo_7, R.drawable.large_photo_8};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtMsg = (TextView) findViewById(R.id.txtMsg);

        imageSelected = (ImageView) findViewById(R.id.imageSelected);
        scrollViewgroup = (ViewGroup)findViewById(R.id.viewgroup);

        for (int i = 0; i < items.length; i++) {
            final View singleFrame = getLayoutInflater().inflate(R.layout.frame_icon_caption, null);

            singleFrame.setId(i);

            TextView caption = (TextView) singleFrame.findViewById(R.id.caption);
            ImageView icon = (ImageView) singleFrame.findViewById(R.id.icon);

            icon.setImageResource(thumbnails[i]);
            caption.setText(items[i]);
            caption.setBackgroundColor(Color.YELLOW);

            scrollViewgroup.addView(singleFrame);

            singleFrame.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    txtMsg.setText("Selected position: " + items[singleFrame.getId()]);
                    showLargeImage(singleFrame.getId());
                }
            });
        }
    }

    protected void showLargeImage(int frameId) {
        Drawable selectedLargeImage = getResources().getDrawable(largeImages[frameId], getTheme()); // API-21 or newer
        imageSelected.setBackground(selectedLargeImage);
    }
}
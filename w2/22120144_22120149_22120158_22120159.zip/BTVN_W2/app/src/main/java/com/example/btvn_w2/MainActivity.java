package com.example.btvn_w2;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private EditText txtMsg;
    private androidx.appcompat.widget.AppCompatButton exitBtn;
    private LinearLayout myScreen;
    private TextView txtSpyBox;
    final String PREF_NAME = "myFile1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_linear);

        //binding GUI elements
        txtMsg = findViewById(R.id.txtMsg);
        exitBtn = findViewById(R.id.exitBtn);
        txtSpyBox = findViewById(R.id.txtSpyBox);
        myScreen = findViewById(R.id.screen1);

        //add click behaviour
        exitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //add text change listener
        txtMsg.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //do nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //do nothing
            }

            @Override
            public void afterTextChanged(Editable s) {
                String chosenColor = s.toString().toLowerCase(Locale.US);//take the raw string value and turn to lower case based on US-standard
                txtSpyBox.setText(chosenColor);
                setBackgroundColor(chosenColor,myScreen);
            }
        });

        Toast.makeText(this,"onCreate",Toast.LENGTH_LONG).show();

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(this,"onRestart",Toast.LENGTH_LONG).show();
    }
    private String retrieveChosenColorFromSharedPrefFile()
    {
        SharedPreferences myFile = getSharedPreferences(PREF_NAME, Activity.MODE_PRIVATE);
        if (myFile != null && myFile.contains("chosenColor"))
        {
            return myFile.getString("chosenColor", "khanh");
        }
        else
        {
            return "khanh";
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this,"onResume",Toast.LENGTH_LONG).show();
    }

    private void saveStateDataToSharedPrefFile()
    {
        SharedPreferences myFile = getSharedPreferences("myFile1", Activity.MODE_PRIVATE);
        SharedPreferences.Editor myEditor = myFile.edit();
        String chosenColor = txtSpyBox.getText().toString();
        myEditor.putString("chosenColor",chosenColor);
        myEditor.apply();
    }
    @Override
    protected void onPause() {
        super.onPause();
        saveStateDataToSharedPrefFile();
        Toast.makeText(this,"onPause",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onStart() {
        super.onStart();
        String chosenColor = retrieveChosenColorFromSharedPrefFile();
        setBackgroundColor(chosenColor, myScreen);
        Toast.makeText(this,"onStart",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this,"onStop",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        Toast.makeText(this,"onDestroy",Toast.LENGTH_LONG).show();
        super.onDestroy();
    }

    private void setBackgroundColor(String chosenColor, LinearLayout screen)
    {
        switch (chosenColor)
        {
            case "huynh":
                screen.setBackgroundColor(0xFFFF0000);
                break;
            case "khiem":
                screen.setBackgroundColor(0xFF000000);
                break;
            case "khai":
                screen.setBackgroundColor(0xFF00FF00);
                break;
            case "khanh":
                screen.setBackgroundColor(0xFF0000FF);
                break;
            default:
                //do nothing
                break;
        }
    }
}
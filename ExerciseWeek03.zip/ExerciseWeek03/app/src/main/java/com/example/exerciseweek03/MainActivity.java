package com.example.exerciseweek03;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.exerciseweek03.R;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput, retypeInput, birthdateInput;
    private RadioGroup radioGroupCoffeeType;
    private CheckBox checkboxTennis, checkboxFootball, checkboxOthers;
    private Button btnSelectDate, btnReset, btnSignup;

    // Giá trị mặc định cho ngày sinh
    private final String DEFAULT_BIRTHDATE = "20/10/1989";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Khởi tạo các view
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        retypeInput = findViewById(R.id.retype_input);
        birthdateInput = findViewById(R.id.birthdate_input);

        radioGroupCoffeeType = findViewById(R.id.radioGroupCoffeeType);

        checkboxTennis = findViewById(R.id.checkbox_tennis);
        checkboxFootball = findViewById(R.id.checkbox_football);
        checkboxOthers = findViewById(R.id.checkbox_others);

        btnSelectDate = findViewById(R.id.btn_select_date);
        btnReset = findViewById(R.id.btn_reset);
        btnSignup = findViewById(R.id.btn_signup);

        // Thiết lập sự kiện cho nút Select để chọn ngày
        btnSelectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });

        // Thiết lập sự kiện cho nút Reset
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetFields();
                Toast.makeText(MainActivity.this, "Fields have been reset", Toast.LENGTH_SHORT).show();
            }
        });

        // Thiết lập sự kiện cho nút Sign-up (có thể thêm chức năng tại đây)
        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Sign-up button clicked", Toast.LENGTH_SHORT).show();
                // Thêm chức năng đăng ký tại đây
            }
        });
    }

    /**
     * Hiển thị DatePickerDialog để chọn ngày
     */
    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    // Tháng bắt đầu từ 0 nên cần cộng thêm 1
                    String selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    birthdateInput.setText(selectedDate);
                }, year, month, day);

        datePickerDialog.show();
    }

    /**
     * Hàm Reset các trường về giá trị mặc định
     */
    private void resetFields() {
        // Xóa các EditText
        usernameInput.setText("");
        passwordInput.setText("");
        retypeInput.setText("");
        birthdateInput.setText(DEFAULT_BIRTHDATE); // Đặt lại ngày sinh về mặc định

        // Bỏ chọn RadioGroup
        radioGroupCoffeeType.clearCheck();

        // Bỏ chọn các CheckBox
        checkboxTennis.setChecked(false);
        checkboxFootball.setChecked(false);
        checkboxOthers.setChecked(false);
    }
}

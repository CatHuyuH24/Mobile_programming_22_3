package com.example.a22120144_22120149_22120158_22120159;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput, retypeInput, birthdateInput;
    private RadioGroup radioGroupGender;
    private RadioButton radMale, radFemale;
    private CheckBox checkboxTennis, checkboxFootball, checkboxOthers;
    private AppCompatButton btnSelectDate, btnReset, btnSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        retypeInput = findViewById(R.id.retype_input);
        birthdateInput = findViewById(R.id.birthdate_input);

        radioGroupGender = findViewById(R.id.radioGroupGender);
        radMale = findViewById(R.id.radMale);
        radFemale = findViewById(R.id.radFemale);

        checkboxTennis = findViewById(R.id.checkbox_tennis);
        checkboxFootball = findViewById(R.id.checkbox_football);
        checkboxOthers = findViewById(R.id.checkbox_others);

        btnSelectDate = findViewById(R.id.btn_select_date);
        btnReset = findViewById(R.id.btn_reset);
        btnSignup = findViewById(R.id.btn_signup);


        birthdateInput.setText("20/10/1989");

        btnSelectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetFields();
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayUserInfo();
            }
        });


    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    birthdateInput.setText(selectedDate);
                }, year, month, day);
        datePickerDialog.show();
    }

    private void resetFields() {
        usernameInput.setText("");
        passwordInput.setText("");
        retypeInput.setText("");
        birthdateInput.setText("20/10/1989");

        radioGroupGender.clearCheck();

        checkboxTennis.setChecked(false);
        checkboxFootball.setChecked(false);
        checkboxOthers.setChecked(false);
    }

    private void displayUserInfo() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();
        String retypePassword = retypeInput.getText().toString().trim();
        String birthdate = birthdateInput.getText().toString().trim();

        int selectedGenderId = radioGroupGender.getCheckedRadioButtonId();
        String gender = "Not Selected";
        if (selectedGenderId == radMale.getId()) {
            gender = "Male";
        } else if (selectedGenderId == radFemale.getId()) {
            gender = "Female";
        }

        StringBuilder hobbiesBuilder = new StringBuilder();
        if (checkboxTennis.isChecked()) {
            hobbiesBuilder.append("Tennis, ");
        }
        if (checkboxFootball.isChecked()) {
            hobbiesBuilder.append("Football, ");
        }
        if (checkboxOthers.isChecked()) {
            hobbiesBuilder.append("Others, ");
        }
        String hobbies = hobbiesBuilder.length() > 0 ?
                hobbiesBuilder.substring(0, hobbiesBuilder.length() - 2) : "None";

        if (!password.equals(retypePassword)) {
            Toast.makeText(this, "Passwords do not match!", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(this, com.example.a22120144_22120149_22120158_22120159.UserInfoActivity.class);
        intent.putExtra("USERNAME", username);
        intent.putExtra("BIRTHDATE", birthdate);
        intent.putExtra("GENDER", gender);
        intent.putExtra("HOBBIES", hobbies);
        intent.putExtra("PASSWORD", password);
        startActivity(intent);
    }
}
package com.example.a22120144_22120149_22120158_22120159;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class UserInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info2);

        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");
        String password = intent.getStringExtra("PASSWORD");
        String birthdate = intent.getStringExtra("BIRTHDATE");
        String gender = intent.getStringExtra("GENDER");
        String hobbies = intent.getStringExtra("HOBBIES");

        TextView userInfoTextView = findViewById(R.id.user_info_text_view);
        StringBuilder asterisks = new StringBuilder();
        for (int i = 0; i < password.length(); i++) {
            asterisks.append("*");
        }
        String userInfo = "Your information registered" + "\n\n" +
                "Username: " + username + "\n\n" +
                "Password: " + asterisks.toString() + "\n\n" +
                "Birthdate: " + birthdate + "\n\n" +
                "Gender: " + gender + "\n\n" +
                "Hobbies: " + hobbies;
        userInfoTextView.setText(userInfo);

        Button exitButton = findViewById(R.id.btn_exit);
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                finishAffinity();
            }
        });
    }
}

package com.example.animation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.animation.R;

public class MainActivity extends AppCompatActivity {

    private Button buttonChange;
    private Button buttonAnimate;
    private ImageView imageToAnimate;

    private boolean isImageVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonChange = findViewById(R.id.button_change);
        buttonAnimate = findViewById(R.id.button_animate);
        imageToAnimate = findViewById(R.id.image_to_animate);

        buttonChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        buttonAnimate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation slideIn = AnimationUtils.loadAnimation(MainActivity.this, R.anim.slide_in_right);
                Animation slideOut = AnimationUtils.loadAnimation(MainActivity.this, R.anim.slide_out_left);
                Animation slideDown = AnimationUtils.loadAnimation(MainActivity.this, R.anim.slide_down);
                Animation slideUp = AnimationUtils.loadAnimation(MainActivity.this, R.anim.slide_up);

                if (isImageVisible) {
                    imageToAnimate.setVisibility(View.GONE);
                    imageToAnimate.startAnimation(slideOut);
                    buttonChange.startAnimation(slideDown);
                    buttonAnimate.startAnimation(slideDown);

                } else {
                    imageToAnimate.startAnimation(slideIn);
                    imageToAnimate.setVisibility(View.VISIBLE);
                    buttonChange.startAnimation(slideUp);
                    buttonAnimate.startAnimation(slideUp);
                }
                isImageVisible = !isImageVisible;
            }
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}
